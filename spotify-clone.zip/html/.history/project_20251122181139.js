console.log("welcome to spotify");

let audioelement= new Audio('');
let songindex=0;
let masterplay=document.getelementbyid(masterplay);

let myprogressbar=document.getelementByid(myprogressbar);


let song=[ { songname:"salam-ishaq",Filepath:"",coverpath:"" },
    { songname:"salam-ishaq",Filepath:" ",coverpath:""},
    { songname:"salam-ishaq",Filepath:"",coverpath:"" },
    { songname:"salam-ishaq",Filepath:"",coverpath: ""},
    { songname:"salam-ishaq",Filepath:"",coverpath:"" },
]

masterPlay.addEventListener('click', () => {
    if (audioelement.paused || audioelement.currentTime <= 0) {
        audioelement.play();
        masterPlay.classList.remove('fa-play-circle');
        masterPlay.classList.add('fa-pause-circle');
        gif.style.opacity = 1;
    } else {
        audioElement.pause();
        masterPlay.classList.remove('fa-pause-circle');
        masterPlay.classList.add('fa-play-circle');
        gif.style.opacity = 0;
    }
});

audioelement.addEventListener('timeupdate',()=>{

console.log('timeupdate');

progress = parseInt((audioelement.currentTime /audioelement.duration) *100)


});


