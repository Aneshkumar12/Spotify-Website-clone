console.log("Welcome to Spotify");

let songIndex = 0;
let audioElement = new Audio("songs/1.mp3");

let masterPlay = document.getElementById("masterplay");
let myProgressBar = document.getElementById("MyProgressBar");
let masterSongName = document.getElementById("masterSongName");
let gif = document.getElementById("gif");

// ALL SONGS (EDIT HERE)
let songs = [
    { songName: "Let Me Love You", filePath: "songs/1.mp3", coverPath: "covers/1.jpg" },
    { songName: "Fade - NCS", filePath: "songs/2.mp3", coverPath: "covers/2.jpg" },
    { songName: "Invincible", filePath: "songs/3.mp3", coverPath: "covers/3.jpg" },
    { songName: "On & On", filePath: "songs/4.mp3", coverPath: "covers/4.jpg" },
    { songName: "Heroes Tonight", filePath: "songs/5.mp3", coverPath: "covers/5.jpg" }
];

// Generate Song List in HTML
let songContainer = document.querySelector(".songItemscontainer");
songContainer.innerHTML = "";

songs.forEach((song, i) => {
    songContainer.innerHTML += `
    <div class="songItems">
        <img src="${song.coverPath}" alt="cover">
        <span>${song.songName}</span>
        <span class="timestamp">3:45 <i id="${i}" class="songItemPlay fas fa-play"></i></span>
    </div>
    `;
});

// PLAY / PAUSE BUTTON
masterPlay.addEventListener("click", () => {
    if (audioElement.paused || audioElement.currentTime <= 0) {
        audioElement.play();
        masterPlay.classList.replace("fa-play", "fa-pause");
        gif.style.opacity = 1;
    } else {
        audioElement.pause();
        masterPlay.classList.replace("fa-pause", "fa-play");
        gif.style.opacity = 0;
    }
});

// UPDATE PROGRESS BAR
audioElement.addEventListener("timeupdate", () => {
    let progress = parseInt((audioElement.currentTime / audioElement.duration) * 100);
    myProgressBar.value = progress;
});

// SEEK SONG
myProgressBar.addEventListener("change", () => {
    audioElement.currentTime = audioElement.duration * myProgressBar.value / 100;
});

// Reset all button icons
const makeAllPlays = () => {
    document.querySelectorAll(".songItemPlay").forEach(el => {
        el.classList.remove("fa-pause");
        el.classList.add("fa-play");
    });
};

// INDIVIDUAL SONG PLAY
document.querySelectorAll(".songItemPlay").forEach(element => {
    element.addEventListener("click", e => {
        makeAllPlays();

        songIndex = parseInt(e.target.id);
        e.target.classList.replace("fa-play", "fa-pause");

        audioElement.src = songs[songIndex].filePath;
        masterSongName.innerText = songs[songIndex].songName;
        audioElement.currentTime = 0;
        audioElement.play();

        masterPlay.classList.replace("fa-play", "fa-pause");
        gif.style.opacity = 1;
    });
});

// NEXT BUTTON
document.getElementById("nextBtn").addEventListener("click", () => {
    songIndex = (songIndex + 1) % songs.length;
    audioElement.src = songs[songIndex].filePath;
    masterSongName.innerText = songs[songIndex].songName;
    audioElement.currentTime = 0;
    audioElement.play();
    masterPlay.classList.replace("fa-play", "fa-pause");
});

// PREVIOUS BUTTON
document.getElementById("prevBtn").addEventListener("click", () => {
    songIndex = (songIndex - 1 + songs.length) % songs.length;
    audioElement.src = songs[songIndex].filePath;
    masterSongName.innerText = songs[songIndex].songName;
    audioElement.currentTime = 0;
    audioElement.play();
    masterPlay.classList.replace("fa-play", "fa-pause");
});
