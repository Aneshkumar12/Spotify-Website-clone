
const prompt = require("prompt-sync")();

let todoList = [];

function addTask() {
    const task = prompt("Enter new task: ");
    todoList.push(task);
    console.log(`Task added: "${task}"`);
}

function removeTask() {
    const index = Number(prompt("Enter task number to remove: "));
    
    if (isNaN(index) || index < 0 || index >= todoList.length) {
        console.log(" invalid task number.");
        return;
    }

    console.log(`removed: "${todoList[index]}"`);
    todoList.splice(index, 1);
}


function viewTasks() {
    if (todoList.length === 0) {
        console.log("No tasks in the list.");
        return;
    }

    console.log("\n To-Do List ");
    todoList.forEach((task, i) => console.log(`${i}. ${task}`));
    console.log("\n");
}


function clearTasks() {
    todoList = [];
    console.log(" All tasks cleared.");
}

while (true) {
    console.log("\nCommands: add | remove | view | clear | exit");
    const command = prompt("enter command: ").toLowerCase(); //tolower means  every capitalletter convert into small letter

    switch (command) {
        case "add":
            addTask();
            break;
        case "remove":
            removeTask();
            break;
        case "view":
            viewTasks();
            break;
        case "clear":
            clearTasks();
            break;
        case "exit":
            console.log("goodbye!");
            process.exit();
        default:
            console.log(" unknown command.enter again");
    }
}
