

console.log("Welcome to Spotify");

let songIndex = 0;
let audioElement = new Audio("let me love you.mpeg");
let masterPlay = document.getElementById("masterplay");
let masterSongName = document.getElementById("masterSongName");
let gif = document.getElementById("gif");
let myProgressBar = document.getElementById("MyProgressBar");
let songItems = Array.from(document.getElementsByClassName("songItems"));
let songPlayBtns = Array.from(document.getElementsByClassName("songItemPlay"));


let songs = [
    { songName: "Let Me Love You", filePath: "let me love you.mpeg", coverPath: "cover.webp" },
    { songName: "BEHTI HAWA", filePath: "behti hawa.mpeg", coverPath: "behti hawa .jpeg" },
    { songName: "Let Me Love You", filePath: "let me love you.mpeg", coverPath: "cover.webp" },
    { songName: "Let Me Love You", filePath: "let me love you.mpeg", coverPath: "cover.webp" },
    { songName: "Let Me Love You", filePath: "let me love you.mpeg", coverPath: "cover.webp" }
];


songItems.forEach((element, i) => {
    element.getElementsByTagName("img")[0].src = songs[i].coverPath;
    element.getElementsByTagName("span")[0].innerText = songs[i].songName;
});


masterPlay.addEventListener("click", () => {
    if (audioElement.paused || audioElement.currentTime <= 0) {
        audioElement.play();
        masterPlay.classList.replace("fa-play", "fa-pause");
        gif.style.opacity = 1;
    } else {
        audioElement.pause();
        masterPlay.classList.replace("fa-pause", "fa-play");
        gif.style.opacity = 0;
    }
});


audioElement.addEventListener("timeupdate", () => {
    let progress = parseInt((audioElement.currentTime / audioElement.duration) * 100);
    myProgressBar.value = progress;
});


myProgressBar.addEventListener("change", () => {
    audioElement.currentTime = (myProgressBar.value * audioElement.duration) / 100;
});


const makeAllPlays = () => {
    songPlayBtns.forEach((element) => {
        element.classList.add("fa-play");
        element.classList.remove("fa-pause");
    });
};


songPlayBtns.forEach((element) => {
    element.addEventListener("click", (e) => {
        makeAllPlays();

        songIndex = parseInt(e.target.id);
        e.target.classList.remove("fa-play");
        e.target.classList.add("fa-pause");

        audioElement.src = songs[songIndex].filePath;
        masterSongName.innerText = songs[songIndex].songName;

        audioElement.currentTime = 0;
        audioElement.play();
        gif.style.opacity = 1;

        masterPlay.classList.replace("fa-play", "fa-pause");
    });
});

document.querySelector(".fa-forward").addEventListener("click", () => {
    songIndex = (songIndex + 1) % songs.length;

    audioElement.src = songs[songIndex].filePath;
    masterSongName.innerText = songs[songIndex].songName;

    makeAllPlays();
    songPlayBtns[songIndex].classList.replace("fa-play", "fa-pause");

    audioElement.currentTime = 0;
    audioElement.play();
    masterPlay.classList.replace("fa-play", "fa-pause");
    gif.style.opacity = 1;
});


document.querySelector(".fa-backward").addEventListener("click", () => {
    songIndex = (songIndex - 1 + songs.length) % songs.length;

    audioElement.src = songs[songIndex].filePath;
    masterSongName.innerText = songs[songIndex].songName;

    makeAllPlays();
    songPlayBtns[songIndex].classList.replace("fa-play", "fa-pause");

    audioElement.currentTime = 0;
    audioElement.play();
    masterPlay.classList.replace("fa-play", "fa-pause");
    gif.style.opacity = 1;
});


audioElement.addEventListener("ended", () => {
    songIndex = (songIndex + 1) % songs.length;

    audioElement.src = songs[songIndex].filePath;
    masterSongName.innerText = songs[songIndex].songName;

    makeAllPlays();
    songPlayBtns[songIndex].classList.replace("fa-play", "fa-pause");

    audioElement.play();
});
